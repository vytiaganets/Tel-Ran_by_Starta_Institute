// var
// let
// const


// alert('Hello');


// string, number, boolean


// '' "" ``


// 12, -23, 2.3

// NaN, -Infinity, Infinity


// console.log(12/0); //Infinity
// console.log(-12/0); //-Infinity


// True, False


// console.log('name' + ' ' + 'surname');

// console.log(`${}`);


// if(){

// }
// else if(){

// }
// else{

// }


// if(True){
//     console.log('hello');
// }


// for(let i=10; i<20; i++){
    
// }


// num = 1;

// num = num + 1;
// num++;

// ++ --;


// let num = 5;

// console.log(num++);
// console.log(num);
// 1. log(num)
// 2. num = num + 1;

// console.log(++num);
// log(6);

// num = num + 2
// num+=2


// num = num - 2
// num-=2

// console.log(num-=2); //3


// for(let num=0; num<10; num++){
//     if(num==5 && num==6){
//         continue;
//     }
//     console.log(num);
// }

// and &&
// or ||


// let array = [1, 3, 6, 13, -12, 0];

// array.push(1, 45, 7, -12);

// console.log(array);

// let thelast = array.pop();

// console.log(thelast);

// console.log(array);

// array.unshift(0);

// console.log(array);

// let deleted = array.shift();

// console.log(deleted);

// console.log(array);


// Дан массив numbers. Вывести в консоль все числа из массива.


// Сформировать новый массив numbers_squared и передать в него все элементы из массива numbers, возведенные в квадрат


// const numbers = [3, 5, 11, 2, 8, 1, 6];

// let numbers_squared = [];

// for(let i=0; i<numbers.length; i++){
//     console.log(numbers[i]);
//     numbers_squared.push(numbers[i]**2);
// }

// console.log(numbers_squared);


// const numbers = [3, 5, 11, 2, 8, 1, 6];

// for(let i=0; i<numbers.length; i++){
//     console.log(numbers[i]);
// }

// let numbers_squared = [];

// for(let i=0; i<numbers.length; i++){
//     numbers_squared.push(numbers[i]**2);
// }

// console.log(numbers_squared);

// Составьте программу, которая выводит на экран все двузначные положительные числа, делящиеся без остатка и на 3 и на 5 (начиная с наименьшего).


// for(let i=10; i<100; i++){
//     if(i%3==0 && i%5==0){
//         console.log(i);
//     }
// }

// Написать цикл, который выводит те числа из массива, которые больше или равны 15.

// let array = [1, 0, -32, 2, 15, 67, 2, -4, 2, 74, 34];

// for(let i=0; i<array.length; i++){
//     if(array[i]>=15){
//         console.log(array[i]);
//     }
// }

// Написать цикл, который выводит только нечетные числа массива.

// let array = [1, 0, -32, 2, 15, 67, 2, -4, 2, 74, 34];

// for(let i=0; i<array.length; i++){
//     if(array[i]%2!=0){ //==1 ==-1
//         console.log(array[i]);
//     }
// }

// Вывести только те значения массива, индекс которых кратен трем.


// let array = [1, 0, -32, 2, 15, 67, 2, -4, 2, 74, 34];


// for(let i=0; i<array.length; i++){
//     if(i%3==0){
//         console.log(array[i]);
//     }
// }

// for(let i=3; i<array.length; i+=3){
//     console.log(array[i]);
// }


// let obj = {
//     id: 2,
//     first_name: 'John',
// }


// 1. У нас есть следующий объект:

    // let user = {
    //     name: "John",
    //     age: 30,
    // };

// Проверьте, что в объекте есть ключ age.

// in

// console.log('age' in user);//true

// if(user.age){
//     console.log('true');
// }

// if('age' in user){
//     console.log('ключ есть');
// }

// 2. Создать объект product с названием(product_name) и ценой(product_price) продукта и выведите данные в консоль.

// let product={
//     product_name: 'phone', 
//     product_price: 30000
// }

// console.log(product);
// console.log(product.product_name);
// console.log(product.product_price);

// 3. Добавить в объект product свойства product_quantity и product_quality.
// product.product_quantity = 4;
// product.product_quality = 'new';


// 4.  Удалить свойство product_quality из объекта product.
// delete product.product_quality;


// В программе объявлена переменная list, которая содержит массив чисел. Используя цикл посчитайте сумму чисел и выведите в консоль.

// let array = [1, 0, -32, 2, 15, 67, 2, -4, 2, 74, 34];

// let sum = 0;


// for(let i=0; i<array.length; i++){
//     sum = sum + array[i];
// }

// console.log(sum);


// В программе объявлена переменная list, представляющая массив положительных и отрицательных численных значений. Используя цикл, выведите в консоль сумму положительных чисел.

// let array = [1, 0, -32, 2, 15, 67, 2, -4, 2, 74, 34];

// let sum_pos = 0;

// for(let i=0; i<array.length; i++){
//     if(array[i]>0){
//         sum_pos = sum_pos + array[i];
//     }
// }

// console.log(sum_pos);

// В программе объявлена переменная list, которая содержит массив чисел. Используя цикл посчитайте разность суммы всех четных чисел и суммы всех нечетных.

// let sum_Odd = 0;
// let sum_Even = 0;

// let array = [1, 0, -32, 2, 15, 67, 2, -4, 2, 74, 34];


// for(let i=0; i<array.length; i++){
//     if(array[i]%2==0){
//         sum_Even = sum_Even + array[i];
//     }
//     else{
//         sum_Odd = sum_Odd + array[i];
//     }
// }

// console.log(sum_Even-sum_Odd);


